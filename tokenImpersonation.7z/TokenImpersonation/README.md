<div align="center">
  <b><i>TokenImpersonation</i></b><br><br>
  <i>List<br>Command for token enumeration</i><br><br>
  <img src="https://i.imgur.com/aac9HuQ.png" width="75%"><br><br><br>
  <i>Adduser<br>Impersonated net user add functionality</i><br><br>
  <img src="https://i.imgur.com/ZXLsFrO.png"><br><br><br>
  <i>Exec<br>Impersonated "cmd.exe /c" to run commands as impersonated users</i><br><br>
  <img src="https://i.imgur.com/qUrGh21.png">
</div>
